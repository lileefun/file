package com.taikang.business.dao.mapper;

import com.taikang.business.dao.entity.A;
import com.taikang.business.dao.entity.AExample;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

public interface AMapper {
    @SelectProvider(type=ASqlProvider.class, method="countByExample")
    long countByExample(AExample example);

    @DeleteProvider(type=ASqlProvider.class, method="deleteByExample")
    int deleteByExample(AExample example);

    @Delete({
        "delete from A",
        "where ID = #{id,jdbcType=VARCHAR}"
    })
    int deleteByPrimaryKey(String id);

    @Insert({
        "insert into A (ID, NAME, ",
        "AGE, NUM_ID)",
        "values (#{id,jdbcType=VARCHAR}, #{name,jdbcType=VARCHAR}, ",
        "#{age,jdbcType=VARCHAR}, #{numId,jdbcType=DECIMAL})"
    })
    int insert(A record);

    @InsertProvider(type=ASqlProvider.class, method="insertSelective")
    int insertSelective(A record);

    @SelectProvider(type=ASqlProvider.class, method="selectByExample")
    @Results({
        @Result(column="ID", property="id", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="NAME", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="AGE", property="age", jdbcType=JdbcType.VARCHAR),
        @Result(column="NUM_ID", property="numId", jdbcType=JdbcType.DECIMAL)
    })
    List<A> selectByExample(AExample example);

    @Select({
        "select",
        "ID, NAME, AGE, NUM_ID",
        "from A",
        "where ID = #{id,jdbcType=VARCHAR}"
    })
    @Results({
        @Result(column="ID", property="id", jdbcType=JdbcType.VARCHAR, id=true),
        @Result(column="NAME", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="AGE", property="age", jdbcType=JdbcType.VARCHAR),
        @Result(column="NUM_ID", property="numId", jdbcType=JdbcType.DECIMAL)
    })
    A selectByPrimaryKey(String id);

    @UpdateProvider(type=ASqlProvider.class, method="updateByExampleSelective")
    int updateByExampleSelective(@Param("record") A record, @Param("example") AExample example);

    @UpdateProvider(type=ASqlProvider.class, method="updateByExample")
    int updateByExample(@Param("record") A record, @Param("example") AExample example);

    @UpdateProvider(type=ASqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(A record);

    @Update({
        "update A",
        "set NAME = #{name,jdbcType=VARCHAR},",
          "AGE = #{age,jdbcType=VARCHAR},",
          "NUM_ID = #{numId,jdbcType=DECIMAL}",
        "where ID = #{id,jdbcType=VARCHAR}"
    })
    int updateByPrimaryKey(A record);
}