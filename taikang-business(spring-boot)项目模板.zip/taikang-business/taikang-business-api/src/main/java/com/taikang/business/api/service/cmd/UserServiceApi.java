package com.taikang.business.api.service.cmd;

import com.taikang.business.api.service.annotation.ApiMethod;
import com.taikang.business.api.service.annotation.ApiService;
import com.taikang.business.api.service.entity.ServiceResult;
import com.taikang.business.common.entity.RequestClientInfo;
import com.taikang.business.common.entity.ResultDTO;
import com.taikang.business.service.user.def.UserService;
import com.taikang.business.service.user.model.UserDTO;
import lombok.extern.slf4j.Slf4j;
import redis.clients.jedis.ShardedJedisPool;

import javax.annotation.Resource;

/**
 * Created by libin on 2018/3/29.
 */
@Slf4j
@ApiService(value = "user")
public class UserServiceApi {

    @Resource
    private UserService userService;

    @Resource
    private ShardedJedisPool shardedJedisPool;


    /**
     * ceshi
     * @param requestClientInfo
     * @return
     */
    @ApiMethod(value = "test",auth = ApiMethod.Auth.OPTION)
    public ServiceResult login(
                               RequestClientInfo requestClientInfo
    ) {
        ResultDTO<UserDTO> register = userService.register(requestClientInfo);
        return new ServiceResult(register);
    }


}
