package com.taikang.business.api.service.exception;

/**
 * Created by libin on 2018/3/29.
 */
public class ACPIllegalArgumentException extends IllegalArgumentException {

    public ACPIllegalArgumentException(String msg)
    {
        super(msg);
    }

}
