package com.taikang.business.api.service.entity;

import lombok.Data;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Type;

/**
 * Created by libin on 2018/3/29.
 */
@Data
public class ApiMethodParam {

    private Method method;

    private String paramName;

    private Annotation[] paramAnnotations;

    private Type paramType;

    private String[] permissionKey;
}
