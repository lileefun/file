package com.taikang.business.api.config;

import com.alibaba.fastjson.serializer.NameFilter;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.support.config.FastJsonConfig;
import com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter;
import com.taikang.business.api.service.ApiMethodService;
import com.taikang.business.common.utils.ConfigPropertiesLoader;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.http.converter.HttpMessageConverter;

/**
 * Created by libin on 2018/3/29.
 */
@Configuration
public class CoreBeanConfiguration {

    @Bean
    public ApiMethodService getApiMethodService() {
        return new ApiMethodService();
    }

    /**
     * 修改spring默认 jackjson  转换器为fastjsons (不用了)
     *
     * @return
     */
    //@Bean
    public HttpMessageConverters fastJsonConverters() {
        FastJsonHttpMessageConverter fastJsonHttpMessageConverter = new FastJsonHttpMessageConverter();
        FastJsonConfig fastJsonConfig = new FastJsonConfig();
        fastJsonConfig.setSerializerFeatures(SerializerFeature.PrettyFormat);
        NameFilter nameFilter = new NameFilter() {
            @Override
            public String process(Object o, String s, Object o1) {
                return s.toLowerCase();
            }
        };
        fastJsonConfig.setSerializeFilters(nameFilter);
        fastJsonHttpMessageConverter.setFastJsonConfig(fastJsonConfig);
        HttpMessageConverter httpMessageConverters = fastJsonHttpMessageConverter;
        return new HttpMessageConverters(httpMessageConverters);

    }



    /**
     * 配置文件读取配置
     *
     * @return
     */
    @Bean
    public PropertySourcesPlaceholderConfigurer createPropertySourcesPlaceholderConfigurer() {
        String confPath = System.getProperty(ConfigPropertiesLoader.CONF_JVM_ROOT_PATH);
        String confSystemPath = System.getProperty(ConfigPropertiesLoader.CONF_JVM_SYSTEM_ROOT_PATH);
        ConfigPropertiesLoader configPropertiesLoader = ConfigPropertiesLoader.loaderInstance(confPath, confSystemPath);
        PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertyPlaceholderConfigurer.setOrder(1);
        propertyPlaceholderConfigurer.setProperties(configPropertiesLoader.getBusinessProperties());
        return propertyPlaceholderConfigurer;
    }

}
