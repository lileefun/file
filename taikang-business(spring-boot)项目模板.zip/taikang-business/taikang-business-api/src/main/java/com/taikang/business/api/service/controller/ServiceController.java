package com.taikang.business.api.service.controller;

import com.alibaba.fastjson.JSON;
import com.taikang.business.api.constants.ErrorCode;
import com.taikang.business.api.constants.ErrorMessages;
import com.taikang.business.api.constants.HttpConstants;
import com.taikang.business.api.service.ApiMethodService;
import com.taikang.business.api.service.annotation.ApiMethod;
import com.taikang.business.api.service.entity.AcpResponse;
import com.taikang.business.api.service.entity.ApiMethodMapping;
import com.taikang.business.api.service.entity.ServiceResult;
import com.taikang.business.api.service.exception.ACPIllegalArgumentException;
import com.taikang.business.api.service.exception.BaseException;
import com.taikang.business.api.utils.Env;
import com.taikang.business.api.utils.ExceptionHandle;
import com.taikang.business.api.utils.HttpTools;
import com.taikang.business.service.user.model.UserDTO;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by libin on 2018/3/29.
 */
@RestController
public class ServiceController {

    Logger logger = LoggerFactory.getLogger(ServiceController.class);

    @Autowired
    private ApiMethodService apiMethodService;

    @RequestMapping(value = "/*",produces = "application/json-gz")
    @ResponseBody
    public ServiceResult apiMethodService(HttpServletRequest request, HttpServletResponse response) {
        AcpResponse acpResult = new AcpResponse(request, response);
        try {

            ApiMethodMapping apiMethodMapping = apiMethodService.lookupApiMethodCommand(request.getMethod(),request.getParameter(HttpConstants.PARAM_CMD_METHOD), request.getParameter(HttpConstants.PARAM_CMD_SERVICE));

            if (apiMethodMapping == null) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_UNKNOWN_METHOD));
                errorInfo(request, response, null, true);
                logger.error(ErrorCode.E_SYS_UNKNOWN_METHOD);
                return null;
            }

            if (!authValidate(request, apiMethodMapping, acpResult)) {
                return null;
            }
            ServiceResult serviceResult = apiMethodService.executeMethod(apiMethodMapping, request, response);
            acpResult.write(serviceResult);
           // return serviceResult;

        } catch (ACPIllegalArgumentException e) {
            if (Env.isProd()) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_PARAM_PROD));
            } else {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_PARAM, e.getMessage()));
            }
            errorInfo(request, response, e, true);
        } catch (BaseException e) {
            acpResult.write(new ServiceResult(e.getCode(), e.getMessage(), true));
            errorInfo(request, response, e, true);
        } catch (Exception e) {
            if (Env.isProd()) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_UNKNOWN_PROD));
            } else {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_UNKNOWN, e + ":" + e.getMessage()));
            }
            errorInfo(request, response, e, true);
        }
        return null;
    }

    private void errorInfo(HttpServletRequest request, HttpServletResponse response, Exception e, boolean sendEmail) {
        Map<String, String> map = new HashMap<String, String>();
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }
        Map<String, String[]> parameterMap = request.getParameterMap();
        Map map2 = new HashMap<>();
        if (parameterMap != null) {
            Iterator<Map.Entry<String, String[]>> iterator = parameterMap.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String[]> next = iterator.next();
                String key = next.getKey();
                String[] value = next.getValue();
                map2.put(key, value[0]);
            }
        }

        String message = "ip[" + HttpTools.getIpAddress(request) + "] headers[" + map + "] url[" + request.getRequestURL() + "] "
                + " param:" + map2;
        logger.error(message);
        logger.error(String.valueOf(this), e);
        if (sendEmail) {
            if (e != null) {
                ExceptionHandle.exceptionHandle(message, e);
            } else {
                ExceptionHandle.errorHandle(message);

            }
        }
    }

    /**
     * 授权检测
     *
     * @param request
     * @param apiMethodMapping
     * @param acpResult
     * @return
     */
    private boolean authValidate(HttpServletRequest request, ApiMethodMapping apiMethodMapping, AcpResponse acpResult) {
        String token = request.getParameter(HttpConstants.PARAM_TOKEN);
        String userInfo = null;
        if (StringUtils.isNotBlank(token)) {
            //Jedis resource = jedisPool.getResource();
            try {
                //userInfo = resource.get(RedisKeyConsts.BUSINESS_USER_LOGIN_TOKEN + token);
            } finally {
                //resource.close();
            }
        }

        //检测用户授权登录
        if (apiMethodMapping.getAuth() == ApiMethod.Auth.REQUIRED) {
            //token不存在
            if (StringUtils.isBlank(token)) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_INVALID_TOKEN, ErrorMessages.getField("E_SYS_INVALID_TOKEN"), true));
                return false;
            }

            //userinfo信息在redis不存在
            if (StringUtils.isBlank(userInfo)) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_INVALID_TOKEN));
                return false;
            }

            UserDTO userDTO = JSON.parseObject(userInfo, UserDTO.class);
            //查询不到用户信息
            if (userDTO == null) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_INVALID_TOKEN, ErrorMessages.getField("E_SYS_INVALID_TOKEN"), true));
                return false;
            }

            String paramUserid = request.getParameter(HttpConstants.PARAM_USERID);

            if (StringUtils.isBlank(paramUserid)) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_INVALID_TOKEN, ErrorMessages.getField("E_SYS_INVALID_TOKEN"), true));
                return false;
            }

            Long userId = NumberUtils.toLong(paramUserid);
            if (NumberUtils.compare(userDTO.getUserId(), userId) != 0) {
                acpResult.write(new ServiceResult(ErrorCode.E_SYS_INVALID_TOKEN, ErrorMessages.getField("E_SYS_INVALID_TOKEN"), true));
                return false;
            }

        }

        request.setAttribute(HttpConstants.ATTRIBUTE_USERID, userInfo);
        return true;

    }


}
