package com.taikang.business.api.constants;

/**
 * Created by libin on 2018/3/29.
 */
public class HttpConstants {

    public final static String PARAM_LNG = "lng";

    public final static String PARAM_LAT = "lat";

    public final static String PARAM_VER = "v";

    public final static String PARAM_CLIENT = "client";


    public final static String PARAM_CMD_SERVICE = "api_s";

    public final static String PARAM_CMD_METHOD = "api_m";

    public final static String PARAM_TOKEN = "token";

    public final static String PARAM_USERID = "userid";

    public final static String ATTRIBUTE_USERID = "attribute_userid";


}
