package com.taikang.business.api.service.annotation;

import java.lang.annotation.*;

/**
 * Created by libin on 2018/3/29.
 */
@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ApiParam {

    String value() default "";

    boolean required() default false;

    public boolean jsonType() default false;

    public String defaultValue() default "";

    public String validateRegx() default  "";
}
