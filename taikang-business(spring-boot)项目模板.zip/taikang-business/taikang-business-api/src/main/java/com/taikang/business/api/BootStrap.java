package com.taikang.business.api;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import java.util.Properties;

/**
 * Created by libin on 2018/3/29.
 */

@SpringBootApplication
@ComponentScan(basePackages = {"com.taikang.business.api","com.taikang.business.service"})
public class BootStrap {

        @Value("conf-path.env")
        private static String conf;

        public static void main(String[] args) throws Exception {
            Properties properties = PropertiesLoaderUtils.loadAllProperties("application-base.properties");
            String confpathEnv = properties.getProperty("conf-path.env");
            if ( StringUtils.isBlank(System.getProperty("conf_root_path")) && StringUtils.isNotBlank(confpathEnv)) {
                System.setProperty("conf_root_path", confpathEnv);
            }
            String confSystempathEnv = properties.getProperty("conf-path.system");
            if ( StringUtils.isBlank(System.getProperty("conf_system_root_path")) && StringUtils.isNotBlank(confSystempathEnv)) {
                System.setProperty("conf_system_root_path", confSystempathEnv);
            }

            SpringApplication app = new SpringApplication(BootStrap.class);
            app.setBannerMode(Banner.Mode.OFF);
            app.run(args);
        }
}
