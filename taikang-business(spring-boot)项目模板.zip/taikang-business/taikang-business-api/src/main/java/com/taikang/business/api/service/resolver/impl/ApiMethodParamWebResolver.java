package com.taikang.business.api.service.resolver.impl;

import com.alibaba.fastjson.JSON;
import com.taikang.business.api.constants.HttpConstants;
import com.taikang.business.api.service.entity.ApiMethodParam;
import com.taikang.business.api.service.exception.ACPIllegalArgumentException;
import com.taikang.business.api.service.resolver.ApiMethodParamResolver;
import com.taikang.business.api.utils.HttpTools;
import com.taikang.business.api.utils.JsonReader;
import com.taikang.business.common.entity.RequestClientInfo;
import com.taikang.business.common.entity.UserAuthInfo;
import com.taikang.business.service.user.model.UserDTO;
import eu.bitwalker.useragentutils.UserAgent;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartRequest;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Type;

/**
 * Created by libin on 2018/3/29.
 */
public class ApiMethodParamWebResolver implements ApiMethodParamResolver {

    private static final Class[] SERVLET_TYPE_CLASS = {HttpServletRequest.class, ServletRequest.class, HttpServletResponse.class,
            ServletResponse.class, MultipartRequest.class, MultipartFile.class, RequestClientInfo.class, UserAuthInfo.class};


    @Override
    public boolean supportCheck(ApiMethodParam apiMethodParam) {
        return ArrayUtils.contains(SERVLET_TYPE_CLASS, apiMethodParam.getParamType());
    }

    @Override
    public Object getParamObject(ApiMethodParam apiMethodParam, HttpServletRequest request, HttpServletResponse response, boolean collectionType) {
        if (supportCheck(apiMethodParam)) {
            Type type = apiMethodParam.getParamType();

            String paramName = apiMethodParam.getParamName();

            if (type.equals(HttpServletRequest.class) || type.equals(ServletRequest.class)) {
                return request;
            } else if (type.equals(HttpServletResponse.class) || type.equals(ServletResponse.class)) {
                return response;
            } else if (type.equals(UserAuthInfo.class)) {
                UserAuthInfo userAuthInfo = null;
                if (apiMethodParam.getPermissionKey() != null) {
                    userAuthInfo = new UserAuthInfo();
                    userAuthInfo.setPermissionKey(apiMethodParam.getPermissionKey());
                }
                return userAuthInfo;

            }else if (type.equals(RequestClientInfo.class)) {
                String paramValue = request.getParameter(HttpConstants.PARAM_CLIENT);
                RequestClientInfo requestClientInfo = new RequestClientInfo();
                if (paramValue != null) {
                    requestClientInfo = JsonReader.fetchObject(paramValue, RequestClientInfo.class,false);
                }

                String userInfo = (String) request.getAttribute(HttpConstants.ATTRIBUTE_USERID);
                String paramToken = request.getParameter(HttpConstants.PARAM_TOKEN);
                String paramUserid = request.getParameter(HttpConstants.PARAM_USERID);
                Long userId = null;
                if (StringUtils.isNotEmpty(paramUserid)) {
                    userId = NumberUtils.toLong(paramUserid, 0L);
                }

                if (StringUtils.isNotEmpty(userInfo) && userId != null) {
                    //登录有效设置用户信息
                    //解析userInfo
                    UserDTO userDTO = JSON.parseObject(userInfo, UserDTO.class);
                    if (userDTO == null || NumberUtils.compare(userDTO.getUserId(), userId) != 0) {
                        throw new ACPIllegalArgumentException("登录用户参数异常");
                    } else {
                        //有效登录 设置用户id和token信息
                        requestClientInfo.setUserIdstr(paramUserid);
                        requestClientInfo.setUserId(userDTO.getUserId());
                        requestClientInfo.setUserToken(paramToken);
                    }
                }

                String paramLat = request.getParameter(HttpConstants.PARAM_LAT);
                String paramLng = request.getParameter(HttpConstants.PARAM_LNG);
                String paramV = request.getParameter(HttpConstants.PARAM_VER);
                requestClientInfo.setToken(paramToken);
                requestClientInfo.setLat(paramLat);
                requestClientInfo.setLng(paramLng);
                requestClientInfo.setVersion(paramV);

                UserAgent userAgent = UserAgent.parseUserAgentString(request.getHeader("User-Agent"));
                if (requestClientInfo != null) {
                    requestClientInfo.setChannel(requestClientInfo.getChannel());
                    requestClientInfo.setDeviceId(requestClientInfo.getDeviceId());
                    requestClientInfo.setPlatform(requestClientInfo.getPlatform());
                    requestClientInfo.setVersion(requestClientInfo.getVersion());
                }

                requestClientInfo.setUserAgent(userAgent);
                requestClientInfo.setClientIp(HttpTools.getIpAddress(request));

                String header = request.getHeader("user-agent");
                if (!StringUtils.isBlank(header)) {
                    if (header.toLowerCase().indexOf("micromessenger") > 0) {// 是微信浏览器
                        requestClientInfo.setWeiXin(true);
                    } else {
                        requestClientInfo.setWeiXin(false);
                    }
                } else {
                    requestClientInfo.setWeiXin(false);
                }

                return requestClientInfo;
            } else if (type.equals(MultipartFile.class)) {
                if (request instanceof MultipartRequest) {
                    MultipartRequest multipartRequest = (MultipartRequest) request;
                    return multipartRequest.getFile(paramName);
                }
            }
        }
        return null;
    }
}
