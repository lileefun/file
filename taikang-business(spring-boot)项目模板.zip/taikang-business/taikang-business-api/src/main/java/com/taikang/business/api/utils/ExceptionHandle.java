package com.taikang.business.api.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.regex.Pattern;

/**
 * Created by libin on 2018/3/29.
 */
public class ExceptionHandle {
    private static final Log log = LogFactory.getLog(ExceptionHandle.class);
    private static Pattern p = Pattern.compile("\\{requesttimestap=\\d*\\}");
        public static void exceptionHandle(String content, Exception e){

        }

    public static void errorHandle(String content){

    }

}
