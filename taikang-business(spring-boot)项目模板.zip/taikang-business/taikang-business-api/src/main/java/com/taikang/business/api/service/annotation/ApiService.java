package com.taikang.business.api.service.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * Created by libin on 2018/3/29.
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface ApiService {

    public String value();

}
