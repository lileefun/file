package com.taikang.business.service.user.def;

import com.taikang.business.common.entity.RequestClientInfo;
import com.taikang.business.common.entity.ResultDTO;
import com.taikang.business.service.user.model.UserDTO;

/**
 * Created by libin on 2018/3/29.
 */
public interface UserService {

    ResultDTO<UserDTO> register(RequestClientInfo requestClientInfo);
}
