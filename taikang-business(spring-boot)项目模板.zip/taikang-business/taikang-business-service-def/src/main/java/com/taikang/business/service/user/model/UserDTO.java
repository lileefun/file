package com.taikang.business.service.user.model;

import com.taikang.business.common.entity.BaseDTO;
import lombok.Data;

import java.io.Serializable;

@Data
public class UserDTO extends BaseDTO implements Serializable {
    private static final long serialVersionUID = -5945788635837371063L;
    private Long userId;

    private String userName;

    private String password;


}
