package com.taikang.business.common.constants;

/**
 * Created by libin on 2018/3/29.
 */
public class RedisKeyConsts {


}

