package com.taikang.business.common.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by libin on 2018/3/29.
 */
@Data
public class BaseDTO implements Serializable {

    private static final long serialVersionUID = 7684745244521023709L;


}
