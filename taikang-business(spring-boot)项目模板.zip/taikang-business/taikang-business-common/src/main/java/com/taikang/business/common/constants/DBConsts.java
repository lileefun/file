package com.taikang.business.common.constants;

/**
 * 功能描述：数据库常量
 *
 * @author libin
 * @since 2016-10-27
 */
public class DBConsts {

}
