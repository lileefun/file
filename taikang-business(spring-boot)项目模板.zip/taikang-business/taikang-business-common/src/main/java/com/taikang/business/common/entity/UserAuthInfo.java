package com.taikang.business.common.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户的权限信息
 * Created by libin on 2018/3/29.
 */
@Data
public class UserAuthInfo implements Serializable {

    private static final long serialVersionUID = 823282129106783951L;
    private String[] permissionKey;
}
