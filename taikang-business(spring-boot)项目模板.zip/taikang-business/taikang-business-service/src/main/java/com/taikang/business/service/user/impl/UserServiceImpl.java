package com.taikang.business.service.user.impl;

import com.github.pagehelper.PageHelper;
import com.taikang.business.common.entity.RequestClientInfo;
import com.taikang.business.common.entity.ResultDTO;
import com.taikang.business.common.entity.ResultDTOTool;
import com.taikang.business.dao.entity.A;
import com.taikang.business.dao.entity.AExample;
import com.taikang.business.dao.mapper.AMapper;
import com.taikang.business.service.user.def.UserService;
import com.taikang.business.service.user.model.UserDTO;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private AMapper aMapper;

    @Override
    @Transactional
    public ResultDTO<UserDTO> register(RequestClientInfo requestClientInfo) {
        ResultDTO resultDTO = new ResultDTO();
        AExample aExample = new AExample();
        AExample.Criteria criteria = aExample.createCriteria().andIdIn(Arrays.<String>asList("1", "2"));
        PageHelper.offsetPage(1, 1);
        List<A> as = aMapper.selectByExample(aExample);
        UserDTO userDTO = new UserDTO();
        userDTO.setUserName("123");
        userDTO.setUserId(123L);
        resultDTO.setData(as);
        ResultDTOTool.setPage(resultDTO,as);
        return ResultDTOTool.setSuccess(resultDTO);
    }

}
