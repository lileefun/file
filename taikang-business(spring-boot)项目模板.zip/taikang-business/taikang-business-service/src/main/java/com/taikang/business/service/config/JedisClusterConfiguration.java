package com.taikang.business.service.config;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisShardInfo;
import redis.clients.jedis.ShardedJedisPool;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j

public class JedisClusterConfiguration {

    @Value("${redis.ips}")
    private String ips;

    @Value("${redis.maxredirections}")
    private int maxredirections;

    @Value("${redis.timeout}")
    private int timeout;


    @Value("${redis.maxIdle}")
    private int maxTotal;

    @Value("${redis.maxIdle}")
    private int maxIdle;


    @Value("${redis.minIdle}")
    private int minIdle;


    @Value("${redis.maxWait}")
    private int maxWait;

    @Value("${redis.testOnBorrow}")
    private Boolean testOnBorrow;


    @Value("${redis.testWhileIdle}")
    private Boolean testWhileIdle;
    @Bean
    public JedisPoolConfig getRedisConfig(){
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(maxTotal);
        config.setMaxIdle(maxIdle);
        config.setMinIdle(minIdle);
        config.setMaxWaitMillis(maxWait);
        config.setTestOnBorrow(testOnBorrow);
        config.setTestWhileIdle(testWhileIdle);
        return config;
    }

    /*@Bean
    public JedisCluster getJedisCluster(){
        Set<HostAndPort> list = new LinkedHashSet<>();
        JedisPoolConfig config = getRedisConfig();
        String[] split = ips.split(",");
        for (String ip : split) {
            String[] split1 = ip.split(":");
            HostAndPort hostAndPort = new HostAndPort(split1[0],Integer.parseInt(split1[1]));
            list.add(hostAndPort);
        }
        JedisCluster jedisCluster = new JedisCluster(list,timeout,maxredirections,config);
        log.info("init JedisCluster ...");
        return jedisCluster;
    }*/



    @Value("${jedis.addr}")
    private String jedisPoolAddr;

    @Value("${jedis.port}")
    private int jedisPoolPort;


    @Bean
    public ShardedJedisPool getShardedJedisPool() {
        JedisPoolConfig config = getRedisConfig();
        List<JedisShardInfo> jedisShardInfos= new ArrayList<JedisShardInfo>();
        String[] split = ips.split(",");
        JedisShardInfo jsi;
        String[] hostarrt;
        for (String host : split) {
            hostarrt = host.split(":");
            jsi = new JedisShardInfo(hostarrt[0].trim(), Integer.parseInt(hostarrt[1].trim()));
            jedisShardInfos.add(jsi);
        }
        return new ShardedJedisPool(config, jedisShardInfos);
    }


}
